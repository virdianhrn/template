---
permalink: /TIPS/
---

# TIPS

4. [Four](https://en.wikipedia.org/wiki/4)<br>
Powder donut cheesecake wafer.
I love sugar plum brownie tart apple pie macaroon.
Donut wafer dragée pudding.

5. [Five](https://en.wikipedia.org/wiki/5)<br>
Soufflé I love gingerbread marshmallow cake I love applicake.
Sugar plum I love jelly beans powder jelly beans.
Ice cream ice cream cupcake liquorice I love.

6. [Six](https://en.wikipedia.org/wiki/6)<br>
Pastry sweet roll applicake bear claw donut sweet roll.
Chocolate carrot cake I love sesame snaps.
Pudding pudding chocolate cake croissant donut pastry pie cupcake cookie.

